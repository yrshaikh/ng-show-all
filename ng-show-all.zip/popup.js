document.addEventListener('DOMContentLoaded', function (tab) {
  chrome.tabs.executeScript(null, { file: "jquery.min.js" }, function() {
      chrome.tabs.executeScript(null, { file: "content.js" });
      setTimeout(function(){window.close()}, 600);
  });
});