Show-Password
==============

A chrome plugin to show/reveal passwords from all your login forms.
